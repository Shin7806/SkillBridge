import { Link } from "react-router";
import { Button } from "../components/Button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "../components/Card";
import { Input } from "../components/Input";
import { Search, Star, MessageSquare, Calendar } from "lucide-react";
import { useState } from "react";

const mockMatches = [
  {
    id: 1,
    name: "Sarah Chen",
    avatar: "SC",
    skills: ["React", "TypeScript", "Web Design"],
    bio: "Frontend developer with 5 years of experience. Love teaching modern web development.",
    rating: 4.9,
    sessions: 47,
  },
  {
    id: 2,
    name: "Alex Rivera",
    avatar: "AR",
    skills: ["Python", "Machine Learning", "Data Science"],
    bio: "Data scientist passionate about making ML accessible to everyone.",
    rating: 4.8,
    sessions: 32,
  },
  {
    id: 3,
    name: "Maya Patel",
    avatar: "MP",
    skills: ["UI/UX Design", "Figma", "Product Design"],
    bio: "Product designer helping people create beautiful user experiences.",
    rating: 5.0,
    sessions: 28,
  },
  {
    id: 4,
    name: "Jordan Lee",
    avatar: "JL",
    skills: ["JavaScript", "Node.js", "GraphQL"],
    bio: "Full-stack engineer who enjoys mentoring junior developers.",
    rating: 4.7,
    sessions: 55,
  },
];

export default function Matching() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Find Your Perfect Match</h1>
        <p className="text-muted-foreground">
          Discover skilled teachers ready to help you learn
        </p>
      </div>

      {/* Search and Filters */}
      <div className="mb-8 flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-slate-400" />
          <Input
            placeholder="Search by skill, name, or expertise..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12"
          />
        </div>
        <Button variant="outline">
          Filters
        </Button>
      </div>

      {/* Matches Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {mockMatches.map((match) => (
          <Card key={match.id} variant="elevated">
            <CardHeader>
              <div className="flex items-start gap-4">
                <div className="size-16 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-xl flex-shrink-0">
                  {match.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <CardTitle>{match.name}</CardTitle>
                  <div className="flex items-center gap-3 mt-1">
                    <div className="flex items-center gap-1">
                      <Star className="size-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm font-medium text-foreground">{match.rating}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">{match.sessions} sessions</span>
                  </div>
                </div>
              </div>
            </CardHeader>

            <CardContent>
              <div className="flex flex-wrap gap-2 mb-4">
                {match.skills.map((skill) => (
                  <span
                    key={skill}
                    className="px-3 py-1 bg-muted text-primary rounded-full text-sm"
                  >
                    {skill}
                  </span>
                ))}
              </div>
              <CardDescription>{match.bio}</CardDescription>
            </CardContent>

            <CardFooter>
              <Link to={`/match/${match.id}`} className="flex-1">
                <Button variant="primary" className="w-full">
                  View Profile
                </Button>
              </Link>
              <Button variant="outline" aria-label="Send message">
                <MessageSquare className="size-5" />
              </Button>
              <Button variant="outline" aria-label="Schedule session">
                <Calendar className="size-5" />
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}
