import { useState } from "react";
import { Button } from "../components/Button";
import { Input, Textarea } from "../components/Input";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "../components/Card";
import { Plus, X, Camera, Star } from "lucide-react";

export default function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: "John Doe",
    email: "john.doe@example.com",
    bio: "I'm a software developer passionate about learning new technologies and sharing knowledge with others. I love teaching programming fundamentals and learning about design.",
    location: "San Francisco, CA",
  });

  const [skillsToTeach, setSkillsToTeach] = useState(["JavaScript", "React", "Node.js"]);
  const [skillsToLearn, setSkillsToLearn] = useState(["UI/UX Design", "Python", "Machine Learning"]);
  const [newSkill, setNewSkill] = useState("");

  const stats = {
    rating: 4.8,
    totalSessions: 24,
    skillsTaught: 3,
    skillsLearned: 5,
  };

  const addSkill = (type: "teach" | "learn") => {
    if (!newSkill.trim()) return;
    if (type === "teach") {
      setSkillsToTeach([...skillsToTeach, newSkill]);
    } else {
      setSkillsToLearn([...skillsToLearn, newSkill]);
    }
    setNewSkill("");
  };

  const removeSkill = (type: "teach" | "learn", skill: string) => {
    if (type === "teach") {
      setSkillsToTeach(skillsToTeach.filter((s) => s !== skill));
    } else {
      setSkillsToLearn(skillsToLearn.filter((s) => s !== skill));
    }
  };

  const handleSave = () => {
    setIsEditing(false);
    // Handle save logic
  };

  return (
    <div className="max-w-5xl mx-auto px-6 py-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">My Profile</h1>
          <p className="text-muted-foreground">Manage your personal information and skills</p>
        </div>
        {!isEditing ? (
          <Button onClick={() => setIsEditing(true)}>Edit Profile</Button>
        ) : (
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setIsEditing(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave}>Save Changes</Button>
          </div>
        )}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Profile Info */}
        <div className="lg:col-span-2 space-y-6">
          {/* Basic Info */}
          <Card variant="elevated">
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Avatar */}
              <div className="flex items-center gap-4">
                <div className="size-20 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-3xl">
                  JD
                </div>
                {isEditing && (
                  <Button variant="outline" size="sm">
                    <Camera className="size-4 mr-2" />
                    Change Photo
                  </Button>
                )}
              </div>

              <Input
                label="Full Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                disabled={!isEditing}
              />

              <Input
                label="Email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                disabled={!isEditing}
              />

              <Input
                label="Location"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                disabled={!isEditing}
              />

              <Textarea
                label="Bio"
                value={formData.bio}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                disabled={!isEditing}
                rows={4}
              />
            </CardContent>
          </Card>

          {/* Skills I Teach */}
          <Card variant="elevated">
            <CardHeader>
              <CardTitle>Skills I Teach</CardTitle>
              <CardDescription>Share your expertise with others</CardDescription>
            </CardHeader>
            <CardContent>
              {isEditing && (
                <div className="flex gap-2 mb-4">
                  <Input
                    placeholder="Add a skill..."
                    value={newSkill}
                    onChange={(e) => setNewSkill(e.target.value)}
                    onKeyPress={(e) =>
                      e.key === "Enter" && (e.preventDefault(), addSkill("teach"))
                    }
                  />
                  <Button type="button" onClick={() => addSkill("teach")}>
                    <Plus className="size-5" />
                  </Button>
                </div>
              )}
              <div className="flex flex-wrap gap-2">
                {skillsToTeach.map((skill) => (
                  <span
                    key={skill}
                    className="inline-flex items-center gap-2 px-3 py-1.5 bg-muted text-primary rounded-lg"
                  >
                    {skill}
                    {isEditing && (
                      <button
                        type="button"
                        onClick={() => removeSkill("teach", skill)}
                        className="hover:opacity-80"
                        aria-label={`Remove ${skill}`}
                      >
                        <X className="size-4" />
                      </button>
                    )}
                  </span>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Skills I Want to Learn */}
          <Card variant="elevated">
            <CardHeader>
              <CardTitle>Skills I Want to Learn</CardTitle>
              <CardDescription>What you're interested in learning</CardDescription>
            </CardHeader>
            <CardContent>
              {isEditing && (
                <div className="flex gap-2 mb-4">
                  <Input
                    placeholder="Add a skill..."
                    value={newSkill}
                    onChange={(e) => setNewSkill(e.target.value)}
                    onKeyPress={(e) =>
                      e.key === "Enter" && (e.preventDefault(), addSkill("learn"))
                    }
                  />
                  <Button type="button" onClick={() => addSkill("learn")}>
                    <Plus className="size-5" />
                  </Button>
                </div>
              )}
              <div className="flex flex-wrap gap-2">
                {skillsToLearn.map((skill) => (
                  <span
                    key={skill}
                    className="inline-flex items-center gap-2 px-3 py-1.5 bg-muted text-accent rounded-lg"
                  >
                    {skill}
                    {isEditing && (
                      <button
                        type="button"
                        onClick={() => removeSkill("learn", skill)}
                        className="hover:opacity-80"
                        aria-label={`Remove ${skill}`}
                      >
                        <X className="size-4" />
                      </button>
                    )}
                  </span>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Stats Sidebar */}
        <div className="space-y-6">
          {/* Stats Card */}
          <Card variant="bordered">
            <CardHeader>
              <CardTitle>Your Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Rating</span>
                <div className="flex items-center gap-1">
                  <Star className="size-4 fill-yellow-400 text-yellow-400" />
                  <span className="font-semibold text-foreground">{stats.rating}</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Total Sessions</span>
                <span className="font-semibold text-foreground">{stats.totalSessions}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Skills Taught</span>
                <span className="font-semibold text-foreground">{stats.skillsTaught}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Skills Learned</span>
                <span className="font-semibold text-foreground">{stats.skillsLearned}</span>
              </div>
            </CardContent>
          </Card>

          {/* Achievements */}
          <Card variant="bordered">
            <CardHeader>
              <CardTitle>Achievements</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="size-10 rounded-lg bg-yellow-100 flex items-center justify-center">
                  <span className="text-xl">🏆</span>
                </div>
                <div>
                  <p className="font-medium text-foreground">Top Teacher</p>
                  <p className="text-xs text-muted-foreground">10+ sessions taught</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="size-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <span className="text-xl">🎓</span>
                </div>
                <div>
                  <p className="font-medium text-foreground">Fast Learner</p>
                  <p className="text-xs text-muted-foreground">5+ skills learned</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="size-10 rounded-lg bg-green-100 flex items-center justify-center">
                  <span className="text-xl">⭐</span>
                </div>
                <div>
                  <p className="font-medium text-foreground">5-Star Rated</p>
                  <p className="text-xs text-muted-foreground">Excellent feedback</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
