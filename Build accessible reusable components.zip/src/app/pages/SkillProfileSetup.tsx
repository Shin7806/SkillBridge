import { Link } from "react-router";
import { Button } from "../components/Button";
import { Input, Textarea } from "../components/Input";
import { Card, CardHeader, CardTitle, CardDescription } from "../components/Card";
import { useState } from "react";
import { Plus, X } from "lucide-react";

export default function SkillProfileSetup() {
  const [step, setStep] = useState(1);
  const [skillsToTeach, setSkillsToTeach] = useState<string[]>([]);
  const [skillsToLearn, setSkillsToLearn] = useState<string[]>([]);
  const [newSkill, setNewSkill] = useState("");
  const [bio, setBio] = useState("");

  const addSkill = (type: "teach" | "learn") => {
    if (!newSkill.trim()) return;
    if (type === "teach") {
      setSkillsToTeach([...skillsToTeach, newSkill]);
    } else {
      setSkillsToLearn([...skillsToLearn, newSkill]);
    }
    setNewSkill("");
  };

  const removeSkill = (type: "teach" | "learn", index: number) => {
    if (type === "teach") {
      setSkillsToTeach(skillsToTeach.filter((_, i) => i !== index));
    } else {
      setSkillsToLearn(skillsToLearn.filter((_, i) => i !== index));
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-12">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Set up your profile</h1>
        <p className="text-muted-foreground">Tell us about your skills and what you'd like to learn</p>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center justify-center gap-2 mb-8">
        {[1, 2, 3].map((num) => (
          <div key={num} className="flex items-center">
            <div
              className={`size-10 rounded-full flex items-center justify-center font-semibold ${
                step >= num
                  ? "bg-primary text-primary-foreground"
                  : "bg-slate-200 text-muted-foreground"
              }`}
            >
              {num}
            </div>
            {num < 3 && (
              <div
                className={`w-16 h-1 ${
                  step > num ? "bg-primary" : "bg-slate-200"
                }`}
              />
            )}
          </div>
        ))}
      </div>

      <Card variant="elevated">
        {step === 1 && (
          <div className="space-y-6">
            <CardHeader>
              <CardTitle>Skills I can teach</CardTitle>
              <CardDescription>
                What skills would you like to share with others?
              </CardDescription>
            </CardHeader>

            <div className="flex gap-2">
              <Input
                placeholder="e.g., JavaScript, Guitar, Spanish"
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addSkill("teach"))}
              />
              <Button type="button" onClick={() => addSkill("teach")} variant="primary">
                <Plus className="size-5" />
              </Button>
            </div>

            <div className="flex flex-wrap gap-2">
              {skillsToTeach.map((skill, index) => (
                <span
                  key={index}
                  className="inline-flex items-center gap-2 px-3 py-1.5 bg-muted text-primary rounded-lg"
                >
                  {skill}
                  <button
                    type="button"
                    onClick={() => removeSkill("teach", index)}
                    className="hover:opacity-80"
                    aria-label={`Remove ${skill}`}
                  >
                    <X className="size-4" />
                  </button>
                </span>
              ))}
            </div>

            <div className="flex justify-end">
              <Button onClick={() => setStep(2)} disabled={skillsToTeach.length === 0}>
                Next
              </Button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <CardHeader>
              <CardTitle>Skills I want to learn</CardTitle>
              <CardDescription>
                What would you like to learn from others?
              </CardDescription>
            </CardHeader>

            <div className="flex gap-2">
              <Input
                placeholder="e.g., Python, Photography, French"
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addSkill("learn"))}
              />
              <Button type="button" onClick={() => addSkill("learn")} variant="primary">
                <Plus className="size-5" />
              </Button>
            </div>

            <div className="flex flex-wrap gap-2">
              {skillsToLearn.map((skill, index) => (
                <span
                  key={index}
                  className="inline-flex items-center gap-2 px-3 py-1.5 bg-muted text-accent rounded-lg"
                >
                  {skill}
                  <button
                    type="button"
                    onClick={() => removeSkill("learn", index)}
                    className="hover:opacity-80"
                    aria-label={`Remove ${skill}`}
                  >
                    <X className="size-4" />
                  </button>
                </span>
              ))}
            </div>

            <div className="flex justify-between">
              <Button onClick={() => setStep(1)} variant="outline">
                Back
              </Button>
              <Button onClick={() => setStep(3)} disabled={skillsToLearn.length === 0}>
                Next
              </Button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6">
            <CardHeader>
              <CardTitle>Tell us about yourself</CardTitle>
              <CardDescription>
                Share a bit about your background and interests
              </CardDescription>
            </CardHeader>

            <Textarea
              label="Bio"
              placeholder="I'm a software developer who loves teaching programming and wants to learn design..."
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={6}
            />

            <div className="flex justify-between">
              <Button onClick={() => setStep(2)} variant="outline">
                Back
              </Button>
              <Link to="/dashboard">
                <Button variant="primary">
                  Complete Setup
                </Button>
              </Link>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
